import { UserCircleIcon } from '@heroicons/react/24/solid'
import { ChevronDownIcon } from '@heroicons/react/16/solid'
import { useState } from 'react'
import './App.css'

function App() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    location: '',
    storeName: ''
  })

  const handleSubmit = (e) => {
    e.preventDefault()

    if (!formData.firstName || !formData.lastName || !formData.phone || !formData.location || !formData.storeName) {
      alert('Mohon lengkapi semua field yang wajib diisi!')
      return
    }

    console.log('Form submitted:', formData)
    alert('Formulir berhasil dikirim!')
    handleCancel()
  }

  const handleCancel = () => {
    setFormData({
      firstName: '',
      lastName: '',
      phone: '',
      location: '',
      storeName: ''
    })
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  return (
    <div className="container">
      {/* Header */}
      <div className="header">
        <h1>ArthiUsaha</h1>
        <p>Solusi Keuangan Terpercaya | Your Financial Consultant</p>
      </div>

      {/* Form Card */}
      <div className="form-card">
        <div className="form-header">
          <h2>Formulir Pendaftaran Nasabah</h2>
          <p>Silakan lengkapi data diri Anda untuk memulai layanan keuangan kami</p>
        </div>

        <div className="form-body">
          <div className="section-title">Data Nasabah</div>

          <div className="form-grid">

            {/* First Name */}
            <div className="form-group">
              <label htmlFor="firstName">Nama Depan <span className="required">*</span></label>
              <input
                type="text"
                id="firstName"
                name="firstName"
                placeholder="Contoh: Budi"
                required
                value={formData.firstName}
                onChange={handleChange}
              />
            </div>

            {/* Last Name */}
            <div className="form-group">
              <label htmlFor="lastName">Nama Belakang <span className="required">*</span></label>
              <input
                type="text"
                id="lastName"
                name="lastName"
                placeholder="Contoh: Santoso"
                required
                value={formData.lastName}
                onChange={handleChange}
              />
            </div>

            {/* Phone */}
            <div className="form-group full-width">
              <label htmlFor="phone">Nomor Telepon <span className="required">*</span></label>
              <input
                type="tel"
                id="phone"
                name="phone"
                placeholder="Contoh: 081234567890"
                required
                value={formData.phone}
                onChange={handleChange}
              />
            </div>

            {/* Customer Email */}
            <div className="form-group full-width">
              <label htmlFor="customerEmail">Email <span className="required">*</span></label>
              <input
                type="text"
                id="customerEmail"
                name="customerEmail"
                placeholder="Contoh: budi@gmail.com"
                required
                value={formData.customerEmail}
                onChange={handleChange}
              />
            </div>

            {/* Location */}
            <div className="form-group full-width">
              <label htmlFor="location">Lokasi <span className="required">*</span></label>
              <input
                type="text"
                id="location"
                name="location"
                placeholder="Contoh: Jakarta Selatan"
                required
                value={formData.location}
                onChange={handleChange}
              />
            </div>

            {/* Store Name */}
            <div className="form-group full-width">
              <label htmlFor="storeName">Nama Toko/Usaha <span className="required">*</span></label>
              <input
                type="text"
                id="storeName"
                name="storeName"
                placeholder="Contoh: Toko Sumber Rejeki"
                required
                value={formData.storeName}
                onChange={handleChange}
              />
            </div>

          </div>

          {/* Privacy Notice */}
          <div className="privacy-notice">
            <p>
              <strong>Informasi Privasi:</strong> Data yang Anda berikan akan kami jaga kerahasiaannya dan hanya digunakan untuk keperluan layanan keuangan ArthiUsaha.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="form-actions">
            <button type="button" className="btn btn-cancel" onClick={handleCancel}>
              Batal
            </button>
            <button type="button" className="btn btn-submit" onClick={handleSubmit}>
              Kirim Formulir
            </button>
          </div>

        </div>
      </div>

      {/* Footer */}
      <div className="footer">
        <p>© 2024 ArthiUsaha. Terdaftar dan diawasi oleh OJK.</p>
      </div>
    </div>
  )
}

export default App
